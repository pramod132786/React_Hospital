import InPatients from "./InPatients";


const InPatientBody = () => {
    return (
        <>

            <InPatients></InPatients>
            

        </>
    )

}
export default InPatientBody;