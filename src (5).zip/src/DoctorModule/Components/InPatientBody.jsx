import InPatients from "./InPatients";


const InPatientBody = () => {
    return (
        <>

            <InPatients></InPatients>
            <div id="content">


                <h1>Hello</h1>
                <h1>Hello</h1>
            </div>

        </>
    )

}
export default InPatientBody;